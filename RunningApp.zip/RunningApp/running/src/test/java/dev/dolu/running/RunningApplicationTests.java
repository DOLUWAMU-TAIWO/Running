package dev.dolu.running;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RunningApplicationTests {

    @Test
    void contextLoads() {
    }

}
