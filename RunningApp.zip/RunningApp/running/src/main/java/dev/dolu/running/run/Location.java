package dev.dolu.running.run;

public enum Location {
    INDOOR,OUTDOOR
}
